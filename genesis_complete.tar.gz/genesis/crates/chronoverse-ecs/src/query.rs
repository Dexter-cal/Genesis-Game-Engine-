pub struct QueryState;
